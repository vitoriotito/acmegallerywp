import $ from 'jquery';

$(".hamburger--slider").on('click', function() {
  $(".hamburger--slider").toggleClass('is-active');
});




