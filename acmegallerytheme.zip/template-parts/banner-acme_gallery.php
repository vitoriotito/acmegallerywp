<?php
/**
 * Template part for displaying banner headers
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package acmegallery
 */

?>


<!-- GALLERY BANNER -->
<section class="banner">
	<div class="banner__container row">
		<h1 class="banner__title">Gallery</h1>
	</div>
</section>

