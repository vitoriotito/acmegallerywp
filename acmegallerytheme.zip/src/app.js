import "bootstrap";
// import './scss/app.scss';
import "../assets/js/main";
import "../assets/js/ajax-loader";
import ajaxLoadMore from "../assets/js/ajax-loader";

ajaxLoadMore();